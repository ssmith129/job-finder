const colors = {
    white: '#FFFFFF',
    black: '#000000',
    background:'#FAFAFD',
    darkgray:"#95969D",
    borderGray:"#AFB0B6",
    lightGray:'#E4E5E7',
    primaryBlack:'#0D0D26',
    primaryBlue:'#3264FF',
    naturalText:'#2C3131',
    eyeGray:'#CACBCE',
    eyeGray:'#CACACA',
    lightblue:'#356899',
    disableGray:'#E9E9E9',
    textGray:'#a9a9a9',
    graynite:'#979797',
    grayborder2:'#E1E1E1',
    black2:'#1C1C28',
    serachGray:'#F2F2F3',
    darkGray2:'#62636A',

  };
  
  export default colors;
//
//  RadioButtonGroupView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 30/08/23.
//

import SwiftUI

enum datePostedFilter: String {
    case any = "Any"
    case past24 = "Past 24 hours"
    case past7 = "Past 7 days"
    case pastMonth = "Past month"
}

enum sortByFilter: String {
    case recent = "Most Recent"
    case relevant = "Most Relevant"
}

struct RadioButtonDatePosted: View {
    let callback: (String) -> ()
    
    @State var selectedId: String = ""
    
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                radioAny
                radioPast24
            }
            HStack {
                radioPast7
                radioPastMonth
            }
        }
    }
    
    var radioAny: some View {
        RadioButtonField(
            id: datePostedFilter.any.rawValue,
            label: datePostedFilter.any.rawValue,
            isMarked: selectedId == datePostedFilter.any.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    var radioPast24: some View {
        RadioButtonField(
            id: datePostedFilter.past24.rawValue,
            label: datePostedFilter.past24.rawValue,
            isMarked: selectedId == datePostedFilter.past24.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    var radioPast7: some View {
        RadioButtonField(
            id: datePostedFilter.past7.rawValue,
            label: datePostedFilter.past7.rawValue,
            isMarked: selectedId == datePostedFilter.past7.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    var radioPastMonth: some View {
        RadioButtonField(
            id: datePostedFilter.pastMonth.rawValue,
            label: datePostedFilter.pastMonth.rawValue,
            isMarked: selectedId == datePostedFilter.pastMonth.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    func radioGroupCallback(id: String) {
        selectedId = id
        callback(id)
    }
}


struct RadioButtonSortby: View {
    let callback: (String) -> ()
    
    @State var selectedId: String = ""
    
    var body: some View {
        HStack {
            radioRecent
            radioRelevant
        }
    }
    
    var radioRecent: some View {
        RadioButtonField(
            id: sortByFilter.recent.rawValue,
            label: sortByFilter.recent.rawValue,
            isMarked: selectedId == sortByFilter.recent.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    var radioRelevant: some View {
        RadioButtonField(
            id: sortByFilter.relevant.rawValue,
            label: sortByFilter.relevant.rawValue,
            isMarked: selectedId == sortByFilter.relevant.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    func radioGroupCallback(id: String) {
        selectedId = id
        callback(id)
    }
}


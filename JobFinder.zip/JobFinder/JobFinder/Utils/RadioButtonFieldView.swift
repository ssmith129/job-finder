//
//  RadioButtonFieldView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 30/08/23.
//

import SwiftUI

struct RadioButtonField: View {
    let id: String
    let label: String
    let size: CGFloat
    let color: Color
    let colorInactive: Color
    let colorTextActive: Color
    let textSize: CGFloat
    let isMarked:Bool
    let callback: (String)->()
    
    init(
        id: String,
        label:String,
        size: CGFloat = 24,
        color: Color = Color(hex: ColorHelper.primary500.description),
        colorInactive: Color = Color(hex: ColorHelper.neutral300.description),
        colorTextActive: Color = Color(hex: ColorHelper.neutral500.description),
        textSize: CGFloat = 14,
        isMarked: Bool = false,
        callback: @escaping (String)->()
        ) {
        self.id = id
        self.label = label
        self.size = size
        self.color = color
        self.colorInactive = colorInactive
        self.colorTextActive = colorTextActive
        self.textSize = textSize
        self.isMarked = isMarked
        self.callback = callback
    }
    
    var body: some View {
        Button(action:{
            self.callback(self.id)
        }) {
            HStack(alignment: .center, spacing: 10) {
                Image(systemName: self.isMarked ? "largecircle.fill.circle" : "circle")
                    .renderingMode(.original)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: self.size, height: self.size)
                    .foregroundColor(self.isMarked ? color : colorInactive)
                Text(label)
                    .font(Font.custom(FontHelper.semibold.description, size: textSize))
                    .foregroundColor(self.isMarked ? colorTextActive : colorInactive)
                Spacer()
            }
        }
        .foregroundColor(Color.white)
    }
}


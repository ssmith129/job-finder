//
//  CheckBoxSingleFieldView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 30/08/23.
//

import Foundation
import SwiftUI


struct CheckListItem:Identifiable{
    var id:Int
    var isChecked: Bool = false
    var title: String
}

let checkListData = [
    CheckListItem(id:0,title: "Neopolitan"),
    CheckListItem(id:1,title: "New York"),
    CheckListItem(id:2,title:"Hawaiian"),
    CheckListItem(id:3,title:"Chicago Deep Dish"),
    CheckListItem(id:4,title:"Californian")
]

struct CheckBoxSingleFieldView: View {
    @State var isChecked:Bool = false
    var title:String
    func toggle(){isChecked = !isChecked}
    var body: some View {
        HStack{
            Button(action: toggle) {
                Image(systemName: isChecked ? "checkmark.square" : "square")
            }
            Text(title)
        }
    }
}

struct CheckBoxStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        // 1
        Button(action: {

            // 2
            configuration.isOn.toggle()

        }, label: {
            HStack {
                // 3
                Image(configuration.isOn ? "checkbox_active" : "checkbox_inactive")
                    .renderingMode(.original)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 24, height: 24)

                configuration.label
            }
        })
    }
}



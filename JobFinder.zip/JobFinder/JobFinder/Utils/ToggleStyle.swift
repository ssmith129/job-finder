//
//  ToggleStyle.swift
//  JobFinder
//
//  Created by Farhan Mazario on 11/07/23.
//

import Foundation



//
//  LoginView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 10/07/23.
//

import SwiftUI

struct LoginView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isOn = false
    
    var body: some View {
        ZStack {
            VStack {
                
                Group {
                    ZStack(alignment: .leading){
                        HStack{
                            VStack(alignment: .leading, spacing: 8){
                                Image(colorScheme == .dark ? "logo_login_dark" :"logo_login")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 48, height: 48)
                                TextView(text: "Welcome Back!", font: FontHelper.extraBold.description, size: 24, colorHex: ColorHelper.white.description)
                                
                                TextView(text: "There’s still a ton of opportunity for you", font: FontHelper.medium.description, size: 16, colorHex: ColorHelper.white.description)
                            }
                            Spacer()
                        }.padding(.horizontal, 24)
                            .padding(.top, 16)
                            .padding(.bottom, 24)
                    }
                    .frame(maxWidth: .infinity)
                    .background(Color(hex: ColorHelper.neutral500.description))
                }
                
                VStack(alignment: .leading) {
                    
                    Group {
                        
                        TFCustom(text: "Email / phone number", fieldText: "example@gmail.com", valueText: $email)
                        
                        TextView(text: "Password", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                            .padding(.bottom, 4)
                        
                        SecureTextField(text: $password)
                    }
                    
                    Group {
                        
                        HStack{
                            Toggle(isOn: $isOn) {
                                TextView(text: "Remember me", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                            }
                            .toggleStyle(iOSCheckboxToggleStyle())
                            Spacer()
                            Button(action: {
                                
                            }, label: {
                                NavigationLink(destination: LoginView()){
                                    TextView(text: "Forgot Password?", font: FontHelper.semibold.description, size: 14, colorHex: ColorHelper.primary500.description)
                                }
                            })
                        }.padding(.top, 12)
                            .padding(.bottom, 16)
                        
                        Button(action: {
                            
                        }, label: {
                            NavigationLink(destination: MainView(selection: 0)){
                                TextView(text: "Sign In", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                                    .padding(.vertical, 16)
                                    .frame(maxWidth: .infinity)
                                    .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                            }
                        })
                        .padding(.bottom, 16)
                    }
                    
                    Group {
                        DividerView(label: "Or continue with")
                            .padding(.bottom, 16)
                        
                        SocialButtonLogin(image: Image("ic_google"), text: Text("Google"))
                            .padding(.bottom, 12)
                        
                        SocialButtonLogin(image: Image("ic_facebook"), text: Text("Facebook"))
                    }
                    
                    Spacer()
                    
                }.padding(.top, 16)
                .padding(.leading, 20)
                .padding(.trailing, 20)
                .frame(maxWidth: .infinity, alignment: .leading)
                
                Spacer()
                TextFooter(text: "Not our member yet?", text2: "Register Now", colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description, destination: RegisterView())
            }
        }
        .navigationBarBackButtonHidden()
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
        
    }
}


struct SecureTextField: View {
    
    @Environment(\.colorScheme) var colorScheme
    @State private var isSecureField: Bool = true
    @Binding var text: String
    var body: some View {
        HStack {
            if isSecureField {
                SecureField("password", text: $text)
                    .font(.custom(FontHelper.medium.description, size: 14))
                    .frame(maxWidth: .infinity)
                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
            } else {
                TextField(text, text: $text).font(.custom(FontHelper.medium.description, size: 14))
                    .frame(maxWidth: .infinity)
                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
            }
        }.overlay(alignment: .trailing) {
            Image(systemName: isSecureField ? "eye.slash": "eye")
                .onTapGesture {
                    isSecureField.toggle()
                }.padding()
        }
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
        )
        .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
        .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
    }
    
}

struct TFCustom: View {
    
    @Environment(\.colorScheme) var colorScheme
    var text: String
    var fieldText: String
    @Binding var valueText: String
    
    var body: some View {
        TextView(text: text, font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
            .padding(.bottom, 4)
        
        TextField(fieldText, text: $valueText)
            .font(.custom(FontHelper.medium.description, size: 14))
            .frame(maxWidth: .infinity)
            .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
            .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
            )
            .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
            .accentColor(Color(.gray))
            .textFieldStyle(PlainTextFieldStyle())
            .padding(.bottom, 12)
    }
}

struct SocialButtonLogin: View {
    
    @Environment(\.colorScheme) var colorScheme
    var image: Image
    var text: Text
    
    var body: some View {
        Button(action: {
            
        }, label: {
            HStack{
                image
                    .padding(.horizontal)
                text
                    .font(.custom(FontHelper.bold.description, size: 16))
                    .foregroundColor(Color(hex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description))
            }
            .padding(.vertical, 16)
            .frame(maxWidth: .infinity)
            .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
            )
        })
    }
}

struct iOSCheckboxToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        // 1
        Button(action: {
            
            // 2
            configuration.isOn.toggle()
            
        }, label: {
            HStack {
                // 3
                Image(systemName: configuration.isOn ? "checkmark.square" : "square")
                
                configuration.label
            }
        })
    }
}

struct TextFooter<Destination: View>: View {
    
    var text: String
    var text2: String
    var colorHex: Int
    var destination: Destination
    
    var body: some View {
        HStack(alignment: .center, spacing: 4) {
            TextView(text: text, font: FontHelper.medium.description, size: 14, colorHex: colorHex)
            
            Button(action: {
                
            }, label: {
                NavigationLink(destination: destination){
                    TextView(text: text2, font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.primary500.description)
                }
            })
        }
        .padding(.bottom, 24)
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}



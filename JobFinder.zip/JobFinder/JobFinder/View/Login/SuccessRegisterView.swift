//
//  SuccessRegisterView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 16/08/23.
//

import SwiftUI

struct SuccessRegisterView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack{
            VStack{
                VStack{
                    Spacer()
                    
                    VStack{
                        Image(colorScheme == .dark ? "success_register_light" :"success_register")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 280, height: 312)
                            .padding(.bottom, 24)
                        TextView(text: "You’re All Set!", font: FontHelper.extraBold.description, size: 24, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                            .padding(.bottom, 4)
                        
                        TextView(text: "You can start searching for job that you wanted or browsing at your feed!", font: FontHelper.medium.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                            .multilineTextAlignment(.center)
                    }.padding(.horizontal, 20)
                    
                    Spacer()
                }
                
                Button(action: {
                    
                }, label: {
                    NavigationLink(destination: MainView()){
                        TextView(text: "Finished", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                    }
                }).padding(.bottom, 20)
            }
            .padding(.horizontal, 20)
        }
    }
}

struct SuccessRegisterView_Previews: PreviewProvider {
    static var previews: some View {
        SuccessRegisterView()
    }
}

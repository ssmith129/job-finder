//
//  ForgotPasswordView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 19/08/23.
//

import SwiftUI

struct ForgotPasswordView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    @State private var email: String = ""
    
    var body: some View {
        ZStack{
            VStack(alignment: .leading){
                
                TextView(text: "Forgot Password", font: FontHelper.extraBold.description, size: 24, colorHex: ColorHelper.neutral500.description)
                    .padding(.top, 24)
                
                TextView(text: "Don’t worry, we got you covered! Just submit us your email and we will send you the OTP code", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                    .padding(.top, 8)
                    .padding(.bottom, 24)
                
                TextView(text: "E-Mail", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                    .padding(.bottom, 4)
                
                HStack {
                    TextField("youremail@gmail.com", text: $email).font(.custom(FontHelper.medium.description, size: 14))
                        .frame(maxWidth: .infinity)
                        .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                }
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                )
                .padding(.bottom, 12)
                .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                
                Button(action: {
                    
                }, label: {
                    NavigationLink(destination: OTPView(OTPData: OTPDataModel.init(), isSelected: true)){
                        TextView(text: "Submit", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                    }
                }).padding(.top, 20)
                
                Spacer()
                
            }.padding(.horizontal, 20)
        }.navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    TextView(text: "Forgot Password", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                        .accessibilityAddTraits(.isHeader)
                }
            }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
    }
}

struct ForgotPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ForgotPasswordView()
    }
}

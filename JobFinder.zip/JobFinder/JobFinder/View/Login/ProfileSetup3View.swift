//
//  ProfileSetup3View.swift
//  JobFinder
//
//  Created by Farhan Mazario on 18/07/23.
//

import SwiftUI

struct ProfileSetup3View: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    @State private var jobTitle: String = ""
    
    var body: some View {
        ZStack{
            VStack{
                VStack(alignment: .leading){
                    TextView(text: "Welcome, Hengki!", font: FontHelper.bold.description, size: 24, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                        .padding(.top, 24)
                    TextView(text: "Your profile will connect to a lot of people. Let’s start submitting it!", font: FontHelper.medium.description, size: 16, colorHex: ColorHelper.neutral300.description)
                        .multilineTextAlignment(.leading)
                        .padding(.top, 4)
                        .padding(.bottom, 32)
                    
                    TextView(text: "Your Job Title", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                        .padding(.bottom, 4)
                    
                    HStack {
                        TextField("Job Title", text: $jobTitle).font(.custom(FontHelper.medium.description, size: 14))
                            .frame(maxWidth: .infinity)
                            .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                    )
                    .padding(.bottom, 12)
                    .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                    .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                    
                    TextView(text: "City/District", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                        .padding(.bottom, 4)
                    
                    HStack {
                        TextField("Semarang, Central Java, Indonesia", text: $jobTitle).font(.custom(FontHelper.medium.description, size: 14))
                            .frame(maxWidth: .infinity)
                            .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                    }.overlay(alignment: .trailing){
                        Image("arrow_down")
                            .padding(.trailing, 24)
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                    )
                    .padding(.bottom, 12)
                    .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                    .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                    
                    Spacer()
                }
                //
                Button(action: {
                    
                }, label: {
                    NavigationLink(destination: ProfileSetup3View()){
                        TextView(text: "Next", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                    }
                }).padding(.bottom, 20)
            }.padding(.horizontal, 20)
        }
        .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    TextView(text: "Profile Setup", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                        .accessibilityAddTraits(.isHeader)
                }
            }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
    }
    
}

struct ProfileSetup3View_Previews: PreviewProvider {
    static var previews: some View {
        ProfileSetup3View()
    }
}

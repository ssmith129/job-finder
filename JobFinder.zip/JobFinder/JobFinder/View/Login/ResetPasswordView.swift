//
//  ResetPasswordView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 19/08/23.
//

import SwiftUI

struct ResetPasswordView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var showAlert = false
    
    var body: some View {
        ZStack{
            
            VStack{
                
                VStack(alignment: .leading) {
                    
                    TextView(text: "Forgot Password", font: FontHelper.extraBold.description, size: 24, colorHex: ColorHelper.neutral500.description)
                        .padding(.top, 24)
                    
                    TextView(text: "Don’t worry, we got you covered! Just submit us your email and we will send you the OTP code", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                        .padding(.top, 8)
                        .padding(.bottom, 24)
                    
                    TextView(text: "New Password", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                        .padding(.bottom, 4)
                    
                    SecureTextField(text: $password)
                        .padding(.bottom, 10)
                    
                    TextView(text: "*Password must have atleast 1 capital letter, 1 number and 1 special character", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.neutral300.description)
                        .padding(.bottom, 1)
                    TextView(text: "**Password must exceed 8 digit", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.neutral300.description)
                        .padding(.bottom, 16)
                    
                    TextView(text: "Re-type Password", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                        .padding(.bottom, 4)
                    
                    SecureTextField2(text: $confirmPassword)
                        .padding(.bottom, 10)
                    
                    Spacer()
                    
                }
                
                Button(action: {
                    self.showAlert = true
                }, label: {
                    NavigationLink(destination: OTPView(OTPData: OTPDataModel.init(), isSelected: true)){
                        TextView(text: "Submit", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                    }
                }).padding(.bottom, 20)
                    .alert("Alert Dialog", isPresented: self.$showAlert) {
                        CustomAlertView(
                                title: "Success!",
                                message: "Your profile was updated successfully.",
                                primaryButtonLabel: "OK",
                                primaryButtonAction: {}
                        )
                }
            }.padding(.horizontal, 20)
            
        }.navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    TextView(text: "Forgot Password", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                        .accessibilityAddTraits(.isHeader)
                }
            }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
    }
}

struct ResetPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ResetPasswordView()
    }
}

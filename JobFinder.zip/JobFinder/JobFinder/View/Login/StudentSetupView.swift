//
//  StudentSetupView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 15/08/23.
//

import SwiftUI

struct StudentSetupView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    @State private var school: String = ""
    @State private var degree: String = ""
    @State private var specialization: String = ""
    @State private var startYear: String = ""
    @State private var endYear: String = ""
    
    @State private var isToggleOn = false
    
    
    
    var body: some View {
        ZStack{
            VStack{
                
                Group {
                    
                    VStack(alignment: .leading){
                        
                        Group {
                            TextView(text: "Welcome, Hengki!", font: FontHelper.bold.description, size: 24, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                                .padding(.top, 24)
                            TextView(text: "Your profile will connect to a lot of people. Let’s start submitting it!", font: FontHelper.medium.description, size: 16, colorHex: ColorHelper.neutral300.description)
                                .multilineTextAlignment(.leading)
                                .padding(.top, 4)
                                .padding(.bottom, 32)
                            
                            TextView(text: "School or College/University", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                .padding(.bottom, 4)
                            
                            HStack {
                                TextField("Diponegoro University", text: $school).font(.custom(FontHelper.medium.description, size: 14))
                                    .frame(maxWidth: .infinity)
                                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                            }
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                            )
                            .padding(.bottom, 12)
                            .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                            .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                            
                            TextView(text: "Degree", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                .padding(.bottom, 4)
                            
                            HStack {
                                TextField("Computer Engineering", text: $degree).font(.custom(FontHelper.medium.description, size: 14))
                                    .frame(maxWidth: .infinity)
                                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                            }
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                            )
                            .padding(.bottom, 12)
                            .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                            .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                            
                            
                            TextView(text: "Specialization", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                .padding(.bottom, 4)
                            
                            HStack {
                                TextField("UI/UX Design", text: $specialization).font(.custom(FontHelper.medium.description, size: 14))
                                    .frame(maxWidth: .infinity)
                                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                            }
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                            )
                            .padding(.bottom, 12)
                            .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                            .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                            
                            
                            
                            
                            
                            
                        }
                        
                        Group {
                            
                            
                            HStack{
                                
                                VStack(alignment: .leading) {
                                    TextView(text: "Start Year", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                        .padding(.bottom, 4)
                                    
                                    ZStack{
                                        Button(action: {
                                        }) {
                                            HStack {
                                                Text("2015")
                                                    .font(.custom(FontHelper.medium.description,size: 14))
                                                    .foregroundColor(Color.gray)
                                                    .frame(maxWidth: .infinity, alignment: .leading)
                                                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                                
                                            }.overlay(alignment: .trailing){
                                                Image("arrow_down")
                                                    .padding(.trailing, 24)
                                            }
                                        }
                                        .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 8)
                                                .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                        )
                                    }
                                }
                                
                                VStack(alignment: .leading) {
                                    TextView(text: "End Year", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                        .padding(.bottom, 4)
                                    
                                    ZStack{
                                        Button(action: {
                                        }) {
                                            HStack {
                                                Text("2019")
                                                    .font(.custom(FontHelper.medium.description,size: 14))
                                                    .foregroundColor(Color.gray)
                                                    .frame(maxWidth: .infinity, alignment: .leading)
                                                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                                
                                            }.overlay(alignment: .trailing){
                                                Image("arrow_down")
                                                    .padding(.trailing, 24)
                                            }
                                        }
                                        .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 8)
                                                .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                        )
                                    }
                                }
                                
                                
                                
                            }.padding(.bottom, 12)
                            
                            
                            //
                            ZStack{
                                Button(action: {
                                }) {
                                    HStack {
                                        Text("I’m over 18 years old")
                                            .font(.custom(FontHelper.medium.description,size: 14))
                                            .foregroundColor(Color.black)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(EdgeInsets(top: 20, leading: 24, bottom: 20, trailing: 24))
                                        
                                    }.overlay(alignment: .trailing){
                                        Toggle(isOn: $isToggleOn) {
                                           
                                        }
                                        .padding(.trailing, 24)
                                        .tint(.red)
                                    }
                                }
                                .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                )
                            }.padding(.bottom, 20)
                            
                        }
                        
                        
                        Spacer()
                    }
                    
                }
                
                
                Group {
                    
                    Button(action: {
                        
                    }, label: {
                        NavigationLink(destination: InterestSetupView()){
                            TextView(text: "Next", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                                .padding(.vertical, 16)
                                .frame(maxWidth: .infinity)
                                .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                        }
                    }).padding(.bottom, 20)
                    
                }
                
                
            }.padding(.horizontal, 20)
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                TextView(text: "Profile Setup", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                    .accessibilityAddTraits(.isHeader)
            }
        }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
    }
}

struct StudentSetupView_Previews: PreviewProvider {
    static var previews: some View {
        StudentSetupView()
    }
}

//
//  OTPPasswordView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 19/08/23.
//

import SwiftUI


struct OTPPasswordView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @ObservedObject var OTPData: OTPDataModel
    
    var isSelected: Bool
    
    var body: some View {
        ZStack{
            VStack(alignment: .leading){
                TextView(text: "OTP Verification", font: FontHelper.bold.description, size: 24, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                    .padding(.top, 48)
                    .padding(.leading, 16)
                TextView(text: "We have send you the 4-digit OTP code to your email.", font: FontHelper.medium.description, size: 16, colorHex: ColorHelper.neutral300.description)
                    .multilineTextAlignment(.leading)
                    .padding(.top, 4)
                    .padding(.leading, 16)
                    .padding(.bottom, 32)
                HStack(spacing: 16){
                    ForEach(0..<4, id: \.self){index in
                        CustomTFOTP(code: getCodeAtIndex(index: index), isSelected: ((OTPData.code.count == index) && (isSelected)) ? true : false)
                    }
                    NavigationLink(destination: ResetPasswordView(), isActive: $OTPData.navigationViewIsActive) {
                        EmptyView()
                    }
                }.frame(maxWidth: .infinity)
                Spacer()
            }
            .padding(.leading, 20)
            .padding(.trailing, 20)
            
            CustomNumericalKeyboardView(data: OTPData)
        }
        .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    TextView(text: "OTP Code", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                        .accessibilityAddTraits(.isHeader)
                }
            }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
    }
    
    func getCodeAtIndex(index:Int)->String{
        
        if OTPData.code.count > index {
            let start = OTPData.code.startIndex
            let current = OTPData.code.index(start, offsetBy: index)
            return String(OTPData.code[current])
        }
        
        return ""
    }
    
}

struct OTPPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        OTPPasswordView(OTPData: OTPDataModel.init(), isSelected: true)
    }
}

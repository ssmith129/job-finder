//
//  InterestSetupView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 16/08/23.
//

import SwiftUI

struct InterestSetupView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack{
            VStack{
                
                VStack(alignment: .leading){
                    
                    Group {
                        TextView(text: "Welcome, Hengki!", font: FontHelper.bold.description, size: 24, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                            .padding(.top, 24)
                        TextView(text: "We will help you find the best job you wanted! Choose at least 5 type of job.", font: FontHelper.medium.description, size: 16, colorHex: ColorHelper.neutral300.description)
                            .multilineTextAlignment(.leading)
                            .padding(.top, 4)
                            .padding(.bottom, 32)
                        
                        Group {
                            HStack(spacing: 16){
                                InactiveInterest(img:"chart_inactive", text: "Big Data")
                                
                                ActiveInterest(imgLight: "design_light", imgDark: "design", text: "Design")
                                
                                ActiveInterest(imgLight: "finance_light", imgDark: "finance", text: "Finance")
                            }.padding(.bottom, 20)
                            
                            HStack(spacing: 16){
                                ActiveInterest(imgLight: "code_light", imgDark: "code", text: "Programmer")
                                
                                InactiveInterest(img:"composer", text: "Composer")
                                
                                InactiveInterest(img:"writer", text: "Writer")
                            }.padding(.bottom, 20)
                            
                            HStack(spacing: 16){
                                InactiveInterest(img:"hrd", text: "HRD")
                                
                                ActiveInterest(imgLight: "photographer_light", imgDark: "photographer", text: "Photographer")
                                
                                ActiveInterest(imgLight: "game_light", imgDark: "game", text: "Gamer")
                            }
                        }
                        
                    }
                    
                }.padding(.horizontal, 20)
                
                Spacer()
                
                Button(action: {
                    
                }, label: {
                    NavigationLink(destination: ProfileSetup3View()){
                        TextView(text: "Next", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                    }
                }).padding(.bottom, 20)
                    .padding(.horizontal, 20)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                TextView(text: "Profile Setup", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                    .accessibilityAddTraits(.isHeader)
            }
        }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
    }
}

struct InterestSetupView_Previews: PreviewProvider {
    static var previews: some View {
        InterestSetupView()
    }
}

struct InactiveInterest: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    var img: String
    var text: String
    
    var body: some View {
        
        Button(action: {
            
        }) {
            VStack(spacing: 12){
                Image(img)
                
                VStack(alignment: .leading){
                    TextView(text: text, font: FontHelper.semibold.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral300.description : ColorHelper.neutral300.description)
                }
            }
            .frame(width: 100, height: 100)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color(hex: colorScheme == .dark ? ColorHelper.neutral300.description : ColorHelper.neutral100.description), lineWidth: 1.5)
            )
        }
        
    }
}

struct ActiveInterest: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    var imgLight: String
    var imgDark: String
    var text: String
    
    var body: some View {
        
        Button(action: {
            
        }) {
            VStack(spacing: 12){
                Image(colorScheme == .dark ? imgDark : imgLight)
                VStack(alignment: .leading){
                    TextView(text: text, font: FontHelper.semibold.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                }
            }
            .frame(width: 100, height: 100)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color(hex: colorScheme == .dark ? ColorHelper.primary500.description : ColorHelper.primary500.description), lineWidth: 1.5)
            )
        }
        
    }
}

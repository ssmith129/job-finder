//
//  ProfileSetup2View.swift
//  JobFinder
//
//  Created by Farhan Mazario on 18/07/23.
//

import SwiftUI
import Combine

struct DropdownOption: Hashable {
    let key: String
    let value: String
    
    public static func == (lhs: DropdownOption, rhs: DropdownOption) -> Bool {
        return lhs.key == rhs.key
    }
}

struct DropdownRow: View {
    var option: DropdownOption
    var onOptionSelected: ((_ option: DropdownOption) -> Void)?
    
    var body: some View {
        Button(action: {
            if let onOptionSelected = self.onOptionSelected {
                onOptionSelected(self.option)
            }
        }) {
            HStack {
                Text(self.option.value)
                    .font(.custom(FontHelper.medium.description,size: 14))
                    .foregroundColor(Color(hex: ColorHelper.neutral400.description))
                Spacer()
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 6)
    }
}

struct Dropdown: View {
    var options: [DropdownOption]
    var onOptionSelected: ((_ option: DropdownOption) -> Void)?
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                ForEach(self.options, id: \.self) { option in
                    DropdownRow(option: option, onOptionSelected: self.onOptionSelected)
                }
            }
        }
        .frame(minHeight: CGFloat(options.count) * 30, maxHeight: 250)
        .padding(.vertical, 6)
        .background(Color.white)
        .cornerRadius(8)
        .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
        )
    }
}


struct ProfileSetup2View: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    @State private var jobTitle: String = ""
    @State private var recentCompany: String = ""
    @State private var masteredSkills: String = ""
    @State private var minSalary: String = ""
    @State private var maxSalary: String = ""
    
    //
    @State private var shouldShowDropdown = false
    @State private var selectedOption: DropdownOption? = nil
    var placeholder: String
    var options: [DropdownOption]
    var onOptionSelected: ((_ option: DropdownOption) -> Void)?
    private let buttonHeight: CGFloat = 45
    
    var body: some View {
        ZStack{
            VStack{
                
                ScrollView(showsIndicators: false) {
                    
                    
                    Group {
                        
                        VStack(alignment: .leading){
                            
                            Group {
                                TextView(text: "Welcome, Hengki!", font: FontHelper.bold.description, size: 24, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                                    .padding(.top, 24)
                                TextView(text: "Your profile will connect to a lot of people. Let’s start submitting it!", font: FontHelper.medium.description, size: 16, colorHex: ColorHelper.neutral300.description)
                                    .multilineTextAlignment(.leading)
                                    .padding(.top, 4)
                                    .padding(.bottom, 32)
                                
                                TextView(text: "Your Job Title", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                    .padding(.bottom, 4)
                                
                                HStack {
                                    TextField("Job Title", text: $jobTitle).font(.custom(FontHelper.medium.description, size: 14))
                                        .frame(maxWidth: .infinity)
                                        .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                }
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                )
                                .padding(.bottom, 12)
                                .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                                
                                TextView(text: "Employment Type", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                    .padding(.bottom, 4)
                                
                                //
                                ZStack{
                                    Button(action: {
                                        self.shouldShowDropdown.toggle()
                                    }) {
                                        HStack {
                                            Text(selectedOption == nil ? placeholder : selectedOption!.value)
                                                .font(.custom(FontHelper.medium.description,size: 14))
                                                .foregroundColor(selectedOption == nil ? Color.gray: Color.black)
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                                .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                            
                                        }.overlay(alignment: .trailing){
                                            Image(self.shouldShowDropdown ? "arrow_up" : "arrow_down")
                                                .padding(.trailing, 24)
                                        }
                                    }
                                    .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                    )
                                    .overlay(
                                        VStack {
                                            if self.shouldShowDropdown {
                                                Spacer(minLength: buttonHeight + 16)
                                                Dropdown(options: self.options, onOptionSelected: { option in
                                                    shouldShowDropdown = false
                                                    selectedOption = option
                                                    self.onOptionSelected?(option)
                                                })
                                            }
                                        }, alignment: .topLeading
                                    )
                                    .background(
                                        RoundedRectangle(cornerRadius: 8).fill(Color.white)
                                    ).padding(.bottom, 12)
                                }
                                
                                TextView(text: "Recent Company", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                    .padding(.bottom, 4)
                                
                                HStack {
                                    TextField("Recent Company", text: $recentCompany).font(.custom(FontHelper.medium.description, size: 14))
                                        .frame(maxWidth: .infinity)
                                        .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                }
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                )
                                .padding(.bottom, 12)
                                .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                                
                                TextView(text: "Mastered Skills", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                    .padding(.bottom, 4)
                                
                                HStack {
                                    TextField("Type your skill", text: $masteredSkills).font(.custom(FontHelper.medium.description, size: 14))
                                        .frame(maxWidth: .infinity)
                                        .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                }
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                )
                                .padding(.bottom, 4)
                                .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                                
                                
                                
                                
                                
                            }
                            
                            Group {
                                
                                HStack{
                                    
                                    Button(action: {
                                        
                                    }, label: {
                                        NavigationLink(destination: ProfileSetup3View()){
                                            HStack {
                                                TextView(text: "UI Design", font: FontHelper.regular.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                                Image("close_red")
                                            }
                                            .padding(12)
                                            .background(colorScheme == .dark ? Color(hex: ColorHelper.neutral300.description) : Color(hex: ColorHelper.neutral100.description), in:RoundedRectangle(cornerRadius: 8))
                                        }
                                    })
                                    
                                    Button(action: {
                                        
                                    }, label: {
                                        NavigationLink(destination: ProfileSetup3View()){
                                            HStack {
                                                TextView(text: "Photoshop", font: FontHelper.regular.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                                Image("close_red")
                                            }
                                            .padding(12)
                                            .background(colorScheme == .dark ? Color(hex: ColorHelper.neutral300.description) : Color(hex: ColorHelper.neutral100.description), in:RoundedRectangle(cornerRadius: 8))
                                        }
                                    })
                                    
                                    Button(action: {
                                        
                                    }, label: {
                                        NavigationLink(destination: ProfileSetup3View()){
                                            HStack {
                                                TextView(text: "Figma", font: FontHelper.regular.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                                Image("close_red")
                                            }
                                            .padding(12)
                                            .background(colorScheme == .dark ? Color(hex: ColorHelper.neutral300.description) : Color(hex: ColorHelper.neutral100.description), in:RoundedRectangle(cornerRadius: 8))
                                        }
                                    })
                                    
                                    
                                    
                                }.padding(.bottom, 12)
                                
                                TextView(text: "Expected Salary", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                    .padding(.bottom, 4)
                                
                                HStack{
                                    
                                    HStack {
                                        TextField("$100", text: $minSalary).font(.custom(FontHelper.medium.description, size: 14))
                                            .frame(maxWidth: .infinity)
                                            .multilineTextAlignment(.center)
                                            .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                    }
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                    )
                                    .padding(.bottom, 4)
                                    .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                    .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                                    
                                    HStack {
                                        TextField("$1000", text: $maxSalary).font(.custom(FontHelper.medium.description, size: 14))
                                            .frame(maxWidth: .infinity)
                                            .multilineTextAlignment(.center)
                                            .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                    }
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                    )
                                    .padding(.bottom, 4)
                                    .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                    .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                                    
                                }
                                
                                TextView(text: "Experience", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                                    .padding(.bottom, 4)
                                
                                //
                                ZStack{
                                    Button(action: {
                                    }) {
                                        HStack {
                                            Text("1-2 years")
                                                .font(.custom(FontHelper.medium.description,size: 14))
                                                .foregroundColor(selectedOption == nil ? Color.gray: Color.black)
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                                .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                                            
                                        }.overlay(alignment: .trailing){
                                            Image("arrow_down")
                                                .padding(.trailing, 24)
                                        }
                                    }
                                    .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                                    )
                                }.padding(.bottom, 20)
                                
                                
                            }
                            
                            
                            Spacer()
                        }
                        
                    }
                    
                    
                    Group {
                        
                        Button(action: {
                        }) {
                            NavigationLink(destination: StudentSetupView()){
                                Text("I’m a student")
                                    .font(
                                        Font.custom("Urbanist", size: 16)
                                            .weight(.bold)
                                    )
                                    .padding(.vertical, 16)
                                    .frame(maxWidth: .infinity)
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(Color(red: 0.92, green: 0.36, blue: 0.14))
                            }
                        }
                        .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .inset(by: 0.75)
                                .stroke(Color(red: 0.92, green: 0.36, blue: 0.14), lineWidth: 1.5)
                        ).padding(.bottom, 12)
                        
                        
                        //
                        Button(action: {
                            
                        }, label: {
                            NavigationLink(destination: ProfileSetup3View()){
                                TextView(text: "Next", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                                    .padding(.vertical, 16)
                                    .frame(maxWidth: .infinity)
                                    .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                            }
                        }).padding(.bottom, 20)
                        
                    }
                    
                }
                
                
            }.padding(.horizontal, 20)
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                TextView(text: "Profile Setup", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                    .accessibilityAddTraits(.isHeader)
            }
        }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
    }
    
    
}

struct ProfileSetup2View_Previews: PreviewProvider {
    static var uniqueKey: String {
        UUID().uuidString
    }
    
    static let options: [DropdownOption] = [
        DropdownOption(key: uniqueKey, value: "Full-time"),
        DropdownOption(key: uniqueKey, value: "Part-time"),
        DropdownOption(key: uniqueKey, value: "Contract"),
        DropdownOption(key: uniqueKey, value: "Internship")
    ]
    
    
    static var previews: some View {
        Group {
            ProfileSetup2View(
                placeholder: "Full-time",
                options: options,
                onOptionSelected: { option in
                    print(option)
                })
            .padding(.horizontal)
        }
    }
}

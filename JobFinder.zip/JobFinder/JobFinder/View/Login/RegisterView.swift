//
//  RegisterView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 11/07/23.
//

import SwiftUI

struct RegisterView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @State private var fullName: String = "Dewa Siwa"
    @State private var email: String = "dewasiwa123@gmail.com"
    @State private var dateBirth: String = "10 July 2023"
    @State private var address: String = "Jakarta Raya Street"
    @State private var phoneNumber: String = "08123456789"
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    
    @State private var isImagePickerPresented = false
    @State private var selectedImage: UIImage?
    
    @State private var selectedDate = Date()
    @State private var isDatePickerShown = false
    
    
    var body: some View {
        
        ZStack {
            ScrollView {
                
                
                VStack(alignment: .leading){
                    TextView(text: "Come Join With Us", font: FontHelper.extraBold.description, size: 24, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                    
                    TextView(text: "There’s still a ton of opportunity for you", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == . dark ? ColorHelper.white.description : ColorHelper.neutral300.description)
                        .padding(.top, 4)
                    
                    HStack{
                        
                        ZStack{
                            if let image = selectedImage {
                                Image(uiImage: image)
                                    .resizable()
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                                    .onTapGesture {
                                                            isImagePickerPresented = true
                                                        }
                            } else {
                                Button(action: {
                                    isImagePickerPresented = true
                                }) {
                                    Image(colorScheme == .dark ? "btn_upload_photo_dark" :"btn_upload_photo")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 100, height: 100)
                                }
                                
                            }
                        }.sheet(isPresented: $isImagePickerPresented, onDismiss: loadImage) {
                            ImagePicker(image: $selectedImage)
                        }
                        Spacer()
                        VStack(alignment: .leading, spacing: 8){
                            TextView(text: "Upload your photo", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                            TextView(text: "MAX 5 MB,JPG*,JPEG*,PNG*", font: FontHelper.medium.description, size: 12, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral300.description)
                        }
                        Spacer()
                        Spacer()
                    }.padding(.vertical, 20)
                    
                    Group {
                        
                        TFCustom(text: "Full Name", fieldText: "", valueText: $fullName)
                        
                        TFCustom(text: "Email Address", fieldText: "", valueText: $email)
                        
                        TextView(text: "Date of Birth", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                            .padding(.bottom, 4)
                        
                        
                        HStack{
                            Text("\(selectedDate, formatter: dateFormatter)")
                                .font(.custom(FontHelper.medium.description, size: 14))
                                .foregroundColor(Color(hex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description))
                            Spacer()
                            Button(action: {
                                isDatePickerShown = true
                            }) {
                                Image("calendar")
                            }
                            .onTapGesture {
                                isDatePickerShown = true
                            }
                            .sheet(isPresented: $isDatePickerShown, content: {
                                
                                GeometryReader { geometry in
                                    DatePicker("", selection: $selectedDate, displayedComponents: [.date])
                                        .datePickerStyle(GraphicalDatePickerStyle())
                                        .labelsHidden()
                                        .onChange(of: selectedDate) { _ in
                                            isDatePickerShown = false
                                        }
                                        .frame(width: geometry.size.width, height: geometry.size.height, alignment: .bottom)
                                        .background(Color.white)
                                }
                            })
                            
                        }
                        .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
                        .frame(maxWidth: .infinity)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                            
                        )
                        .padding(.bottom, 12)
                        .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                        .accentColor(Color(.gray))
                        
                        
                        
                        
                        TFCustom(text: "Address", fieldText: "", valueText: $address)
                        
                        TextView(text: "Phone Number", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                            .padding(.bottom, 4)
                        
                        HStack {
                            TextField("08x", text: $phoneNumber).font(.custom(FontHelper.medium.description, size: 14))
                                .frame(maxWidth: .infinity)
                                .padding(EdgeInsets(top: 16, leading: 56, bottom: 16, trailing: 24))
                        }.overlay(alignment: .leading) {
                            Image("ina")
                                .padding(.leading, 24)
                        }
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
                        )
                        .padding(.bottom, 12)
                        .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                        .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
                        
                    }
                    
                    Group {
                        TextView(text: "Password", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                            .padding(.bottom, 4)
                        
                        SecureTextField(text: $password)
                            .padding(.bottom, 12)
                        
                        VStack(alignment: .leading, spacing: 4){
                            TextView(text: "*Password must have atleast 1 capital letter, 1 number and 1 special character", font: FontHelper.regular.description, size: 12, colorHex: ColorHelper.neutral300.description)
                            TextView(text: "**Password must exceed 8 digit", font: FontHelper.regular.description, size: 12, colorHex: ColorHelper.neutral300.description)
                        }.padding(.bottom, 12)
                        
                        TextView(text: "Confirm Password", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral200.description : ColorHelper.neutral500.description)
                            .padding(.bottom, 4)
                        
                        SecureTextField2(text: $confirmPassword)
                        
                    }
                    
                    Spacer()
                    
                }.padding(.horizontal, 20)
                    .padding(.vertical, 16)
                
                Group{
                    VStack(alignment: .center){
                        TextFooter(text: "By registering, you agree with our", text2: "Terms & Policy.", colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description, destination: RegisterView())
                    }
                    
                    Button(action: {
                        
                    }, label: {
                        NavigationLink(destination: OTPView(OTPData: OTPDataModel.init(), isSelected: true)){
                            TextView(text: "Confirm", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                                .padding(.vertical, 16)
                                .frame(maxWidth: .infinity)
                                .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                        }
                    })
                    .padding(.bottom, 16)
                }.padding(.horizontal, 20)
                
                
            }
        }.navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    TextView(text: "Register", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                        .accessibilityAddTraits(.isHeader)
                }
            }
            .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
        
    }
    
    func loadImage() {
        guard let selectedImage = selectedImage else { return }
        // Perform any further operations with the selected image, such as uploading
    }
    
    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter
    }
}

struct SecureTextField2: View {
    
    @Environment(\.colorScheme) var colorScheme
    @State private var isSecureField: Bool = true
    @Binding var text: String
    var body: some View {
        HStack {
            if isSecureField {
                SecureField("password", text: $text)
                    .font(.custom(FontHelper.medium.description, size: 14))
                    .frame(maxWidth: .infinity)
                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
            } else {
                TextField(text, text: $text).font(.custom(FontHelper.medium.description, size: 14))
                    .frame(maxWidth: .infinity)
                    .padding(EdgeInsets(top: 16, leading: 24, bottom: 16, trailing: 24))
            }
        }.overlay(alignment: .trailing) {
            Image(systemName: isSecureField ? "eye.slash": "eye")
                .onTapGesture {
                    isSecureField.toggle()
                }.padding()
        }
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(hex: ColorHelper.neutral100.description), lineWidth: 1.5)
        )
        .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
        .accentColor(colorScheme == .dark ? Color(.white) : Color(.gray))
    }
    
}


struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePicker
        
        init(_ parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.image = image
            }
            picker.dismiss(animated: true)
        }
    }
}

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView()
    }
}

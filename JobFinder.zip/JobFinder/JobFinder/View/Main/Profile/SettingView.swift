//
//  SettingView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 22/09/23.
//

import SwiftUI

struct SettingView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    @State private var toggleLocation = false
    @State private var toggleNotif = false
    
    var body: some View {
        ZStack{
            VStack(alignment: .leading){
                
                Group {
                    
                    ButtonSettingView(text: "Edit Profile", imgDark: "ic_edit_profile_light", imgLight: "ic_edit_profile")
                        .padding(.top, 32)
                    
                    ButtonSettingView(text: "Bookmark", imgDark: "ic_bookmark_light", imgLight: "ic_bookmark")
                        .padding(.top, 12)
                    
                    ButtonSettingView(text: "Change Password", imgDark: "ic_change_password_light", imgLight: "ic_change_password")
                        .padding(.top, 12)
                    
                    Button(action: {
                        
                    }, label: {
                        HStack{
                            VStack(alignment: .leading){
                                HStack{
                                    Image(colorScheme == .dark ? "ic_setting_location_light" : "ic_setting_location")
                                        .padding(.trailing, 16)
                                    
                                    TextView(text: "Location", font: FontHelper.bold.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                                    Spacer()
                                    Toggle(isOn: $toggleLocation) {
                                        
                                    }
                                    .tint(Color(hex: ColorHelper.primary500.description))
                                }
                            }
                            .padding(16)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                        }
                    }).padding(.horizontal, 24)
                        .padding(.top, 12)
                    
                    Button(action: {
                        
                    }, label: {
                        HStack{
                            VStack(alignment: .leading){
                                HStack{
                                    Image(colorScheme == .dark ? "ic_setting_notification_light" : "ic_setting_notification")
                                        .padding(.trailing, 16)
                                    
                                    TextView(text: "Notification", font: FontHelper.bold.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                                    Spacer()
                                    Toggle(isOn: $toggleNotif) {
                                        
                                    }
                                    .tint(Color(hex: ColorHelper.primary500.description))
                                }
                            }
                            .padding(16)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                        }
                    }).padding(.horizontal, 24)
                        .padding(.top, 12)
                    
                    ButtonSettingView(text: "Language", imgDark: "ic_language_light", imgLight: "ic_language")
                        .padding(.top, 12)
                    
                    Button(action: {
                        
                    }, label: {
                        HStack{
                            VStack(alignment: .leading){
                                HStack{
                                    Image(colorScheme == .dark ? "ic_app_version_light" : "ic_app_version")
                                        .padding(.trailing, 16)
                                    
                                    TextView(text: "App Version", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                                    Spacer()
                                    TextView(text: "1.3", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.primary500.description)
                                }
                            }
                            .padding(16)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                        }
                    }).padding(.horizontal, 24)
                        .padding(.top, 12)
                    
                }
                
                Spacer()
              
                Button(action: {
                    
                }, label: {
                    NavigationLink(destination: LoginView()){
                        TextView(text: "Log out", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                    }
                }).padding(.bottom, 24)
                    .padding(.horizontal, 24)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                TextView(text: "Setting", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                    .accessibilityAddTraits(.isHeader)
            }
        }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
    }
    
    
}

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView()
    }
}

struct ButtonSettingView: View {
    
    @Environment(\.colorScheme) var colorScheme
    var text: String
    var imgDark: String
    var imgLight: String
    
    var body: some View {
        
        Button(action: {
            
        }, label: {
            HStack{
                VStack(alignment: .leading){
                    HStack{
                        Image(colorScheme == .dark ? imgDark : imgLight)
                            .padding(.trailing, 16)
                        TextView(text: text, font: FontHelper.bold.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                        Spacer()
                        Image("ic_arrow_right")
                    }
                }
                .padding(16)
                    .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                    .cornerRadius(8)
                    .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
            }
        }).padding(.horizontal, 24)
        
    }
}

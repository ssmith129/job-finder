//
//  ProfileView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 19/08/23.
//

import SwiftUI

struct ProfileView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack{
            VStack(alignment: .leading){
                
                Group {
                    VStack(spacing: 0){
                        
                        ZStack{
                            
                            VStack {
                                
                                HStack{
                                    TextView(text: "Profile", font: FontHelper.extraBold.description, size: 24, colorHex: ColorHelper.white.description)
                                    Spacer()
                                    Button(action: {
                                        
                                    }, label: {
                                        NavigationLink(destination: SettingView()){
                                            Image("btn_setting")
                                        }
                                    })
                                }
                                
                                Spacer()
                            }
                            
                        }.padding(24)
                            .frame(height: 184)
                            .background(Color(hex: ColorHelper.neutral500.description))
                        
                        HStack{
                            
                            VStack(alignment: .center){
                                
                                Image("img_profile")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 80, height: 80)
                                    .padding(.bottom, 10)
                                
                                TextView(text: "Hengki Komarudin", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description).padding(.bottom, 0.5)
                                
                                TextView(text: "UI/UX Designer", font: FontHelper.bold.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description).padding(.bottom, 16)
                                    
                                HStack(alignment: .center){
                                    
                                    VStack(alignment: .center){
                                        TextView(text: "75", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description).padding(.bottom, 4)
                                        TextView(text: "Job aplied", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral300.description : ColorHelper.neutral300.description)
                                    }
                                    Spacer()
                                    Image("ic_divider")
                                    Spacer()
                                    VStack(alignment: .center){
                                        TextView(text: "19/02/2020", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description).padding(.bottom, 4)
                                        TextView(text: "Member since", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral300.description : ColorHelper.neutral300.description)
                                    }
                                    Spacer()
                                    Image("ic_divider")
                                    Spacer()
                                    VStack(alignment: .center){
                                        TextView(text: "30", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description).padding(.bottom, 4)
                                        TextView(text: "Interview", font: FontHelper.medium.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.neutral300.description : ColorHelper.neutral300.description)
                                    }
                                }
                                
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 24)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, -80)
                        
                    }
                }
                
                Group {
                    
                    TextView(text: "My Skills", font: FontHelper.extraBold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                        .padding(.leading, 24)
                        .padding(.top, 12)
                    
                    HStack(spacing: 12){
                        Button(action: {
                            
                        }, label: {
                            TextView(text: "UI/UX Design", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                        })
                        
                        Button(action: {
                            
                        }, label: {
                            TextView(text: "Graphic Design", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                        })
                        
                        Button(action: {
                            
                        }, label: {
                            TextView(text: "Figma", font: FontHelper.bold.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                        })
                    }.padding(.horizontal, 24)
                        .padding(.top, 12)
                    
                    HStack(spacing: 12){
                        Button(action: {
                            
                        }, label: {
                            TextView(text: "Wireframe", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                        })
                        
                        Button(action: {
                            
                        }, label: {
                            TextView(text: "Adobe XD", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                        })
                        
                        Button(action: {
                            
                        }, label: {
                            TextView(text: "Adobe Illustrator", font: FontHelper.bold.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                        })
                    }.padding(.horizontal, 24)
                        .padding(.top, 4)
                    
                    
                    HStack(spacing: 12){
                        
                        HStack{
                            
                            VStack(alignment: .center){
                                Image("ic_sketch")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 32, height: 32)
                                TextView(text: "Sketch", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.neutral300.description)
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                        }
                        
                        HStack{
                            
                            VStack(alignment: .center){
                                Image("ic_figma")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 32, height: 32)
                                TextView(text: "Figma", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.neutral300.description)
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                        }
                        
                        HStack{
                            
                            VStack(alignment: .center){
                                Image("ic_adobexd")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 32, height: 32)
                                TextView(text: "Adobe XD", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.neutral300.description)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                        }
                        
                        HStack{
                            
                            VStack(alignment: .center){
                                Image("ic_adobeil")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 32, height: 32)
                                TextView(text: "Adobe Ai", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.neutral300.description)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                        }
                    }
                        .padding(.horizontal, 24)
                        .padding(.top, 12)
                    
                    
                }
                
                Group {
                    
                    TextView(text: "Experience", font: FontHelper.extraBold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                        .padding(.leading, 24)
                        .padding(.top, 12)
                    
                    HStack{
                        
                        VStack(alignment: .leading){
                            HStack{
                                Image("ic_figma")
                                VStack(spacing: 8){
                                    HStack{
                                        TextView(text: "UI Manager", font: FontHelper.semibold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                                        Spacer()
                                    }
                                    HStack{
                                        TextView(text: "At AirBNB", font: FontHelper.semibold.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                        Spacer()
                                        TextView(text: "2 years", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.primary500.description)
                                    }
                                }
                            }
                        }
                        .padding(16)
                            .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                            .cornerRadius(8)
                            .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                    }
                    .padding(.horizontal, 24)
                    
                }
                
                Spacer()
            }
        }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}

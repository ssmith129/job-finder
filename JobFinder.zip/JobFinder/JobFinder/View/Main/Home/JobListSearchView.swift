//
//  JobListSearchView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 28/08/23.
//

import SwiftUI

struct JobListSearchView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    var jobList = [
        JobList(jobName: "UI Researcher", image: "ic_dribble", company: "Dribbble", location: "Jakarta, Indonesia", salary: "$40k/month", jobType: "On-Site", date: "8 days left"),
        JobList(jobName: "Senior Web Developer", image: "ic_netflix", company: "Netflix", location: "London, UK", salary: "$125k/month", jobType: "Remote", date: "5 days left"),
        JobList(jobName: "iOS Developer", image: "ic_meta", company: "Meta", location: "Washington, USA", salary: "200k/month", jobType: "On-Site", date: "12 days left"),
        JobList(jobName: "Moderator", image: "ic_discord", company: "Discord", location: "Jogja, Indonesia", salary: "$78k/month", jobType: "On-Site", date: "29 days left")
    ]
    
    var body: some View {
        ZStack{
            VStack{
                
                Group {
                    VStack(alignment: .leading){
                        
                        ZStack{
                            
                            HStack{
                                
                                Button(action: {
                                    
                                }) {
                                    HStack {
                                        Text("Search Jobs...")
                                            .font(.custom(FontHelper.medium.description,size: 14))
                                            .foregroundColor(Color(hex: ColorHelper.neutral300.description))
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(EdgeInsets(top: 12, leading: 56, bottom: 12, trailing: 24))
                                        
                                    }.overlay(alignment: .leading){
                                        Image(colorScheme == .dark ? "ic_search" : "ic_search_light")
                                            .padding(.leading, 20)
                                    }
                                }
                                .frame(height: 48)
                                .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color(hex: ColorHelper.neutral400.description), lineWidth: 1.5)
                                )
                                .background(
                                    RoundedRectangle(cornerRadius: 8).fill(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                )
                                Spacer()
                                Image("btn_filter")
                            }
                            
                        }.padding(24)
                            .background(Color(hex: ColorHelper.neutral500.description))
                        
                        ScrollView(showsIndicators: false) {
                            VStack(alignment: .leading){
                                TextView(text: "14 jobs available", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description).padding(24)
                                
                                ForEach(jobList) { list in
                                    JobListRow(jobList: list)
                                }
                            }
                        }
                    }
                }
                Spacer()
                
            }
        }
        .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    TextView(text: "Search", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.white.description)
                        .accessibilityAddTraits(.isHeader)
                }
            }
    }
}

struct JobListSearchView_Previews: PreviewProvider {
    static var previews: some View {
        JobListSearchView()
    }
}

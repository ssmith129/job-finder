//
//  MapView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 27/11/23.
//

import SwiftUI
import MapKit

struct MapView: View {
    
    @State private var region = 
    MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 37.4300, longitude: -122.1700), span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
    
    var body: some View {
        
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        Map
        
    }
}

#Preview {
    MapView()
}

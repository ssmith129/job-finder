//
//  HomeView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 11/07/23.
//

import SwiftUI

struct HomeView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @State private var search: String = ""
    
    var body: some View {
        ZStack{
            VStack{
                
                Group {
                    VStack(spacing: 0){
                        
                        ZStack{
                            
                            VStack {
                                
                                HStack{
                                    Image("img_avatar")
                                        .padding(.trailing, 4)
                                    VStack(alignment: .leading, spacing: 4){
                                        TextView(text: "Hello John Doe,", font: FontHelper.semibold.description, size: 12, colorHex: ColorHelper.white.description)
                                        
                                        TextView(text: "Let’s start find your dream job", font: FontHelper.semibold.description, size: 14, colorHex: ColorHelper.neutral200.description)
                                    }
                                    Spacer()
                                    Image("ic_notification")
                                        .padding(.trailing, 12)
                                }.padding(.bottom, 20)
                                
                                HStack{
                                    
                                    Button(action: {
                                        
                                    }) {
                                        HStack {
                                            NavigationLink(destination: JobListSearchView()){
                                                Text("Search Jobs...")
                                                    .font(.custom(FontHelper.medium.description,size: 14))
                                                    .foregroundColor(Color(hex: ColorHelper.neutral300.description))
                                                    .frame(maxWidth: .infinity, alignment: .leading)
                                                    .padding(EdgeInsets(top: 12, leading: 56, bottom: 12, trailing: 24))
                                            }
                                        }.overlay(alignment: .leading){
                                            Image("ic_search")
                                                .padding(.leading, 20)
                                        }
                                    }
                                    .frame(height: 48)
                                    .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color(hex: ColorHelper.neutral400.description), lineWidth: 1.5)
                                    )
                                    .background(
                                        RoundedRectangle(cornerRadius: 8).fill(Color(hex: ColorHelper.neutral500.description))
                                    )
                                    Spacer()
                                    Button(action: {
                                        
                                    }, label: {
                                        NavigationLink(destination: FilterJobView()){
                                            Image("btn_filter")
                                        }
                                    })
                                }
                                
                            }
                            
                        }.padding(24)
                            .background(Color(hex: ColorHelper.neutral500.description))
                        
                        ZStack{
                            HStack{
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 12){
                                        Button(action: {
                                            
                                        }, label: {
                                            TextView(text: "Design", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                                                .padding(.vertical, 12)
                                                .padding(.horizontal, 24)
                                                .background(Color(hex: ColorHelper.white.description), in:RoundedRectangle(cornerRadius: 8))
                                        })
                                        
                                        Button(action: {
                                            
                                        }, label: {
                                            TextView(text: "Programmer", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                                                .padding(.vertical, 12)
                                                .padding(.horizontal, 24)
                                                .frame(maxWidth: .infinity)
                                                .background(Color(hex: ColorHelper.white.description, opacity: 0.24), in:RoundedRectangle(cornerRadius: 8))
                                        })
                                        
                                        Button(action: {
                                            
                                        }, label: {
                                            TextView(text: "Business", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                                                .padding(.vertical, 12)
                                                .padding(.horizontal, 24)
                                                .frame(maxWidth: .infinity)
                                                .background(Color(hex: ColorHelper.white.description, opacity: 0.24), in:RoundedRectangle(cornerRadius: 8))
                                        })
                                    }
                                    .padding(.horizontal, 24)
                                    .padding(.vertical, 16)
                                }
                            }
                            .background(Color(hex: ColorHelper.primary500.description))
                        }
                        
                    }
                }
                
                Group {
                    
                    HStack{
                        TextView(text: "Recommended for you", font: FontHelper.extraBold.description, size: 18, colorHex: ColorHelper.neutral500.description)
                        Spacer()
                        Button(action: {
                            
                        }, label: {
                            TextView(text: "See All", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.primary500.description)
                        })
                    }.padding(.horizontal, 24)
                        .padding(.vertical, 12)
                    
                        
                    
                    ZStack{
                        HStack{
                            ScrollView(.horizontal, showsIndicators: false){
                                HStack(spacing: 12){
                                    VStack(alignment: .leading){
                                        HStack{
                                            Image("ic_google_ads")
                                            VStack(alignment: .leading){
                                                TextView(text: "Google Ads", font: FontHelper.semibold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                                                HStack{
                                                    Image("ic_location")
                                                    TextView(text: "Jakarta, Indonesia", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                                    
                                                }
                                            }
                                        }
                                        
                                        HStack{
                                            Image("ic_money_send")
                                            TextView(text: "Start from $12k/month", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.neutral500.description)
                                        }.padding(.top, 16)
                                        
                                        HStack{
                                            Image("ic_clock")
                                            TextView(text: "Until 28 Dec, 2022", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.neutral500.description)
                                        }.padding(.top, 4)
                                        
                                    }.padding(16)
                                        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                        .cornerRadius(8)
                                        .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                                    
                                    VStack(alignment: .leading){
                                        HStack{
                                            Image("ic_qiwi")
                                            VStack(alignment: .leading){
                                                TextView(text: "Qiwi Indonesia", font: FontHelper.semibold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                                                HStack{
                                                    Image("ic_location")
                                                    TextView(text: "Bandung, Indonesia", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                                    
                                                }
                                            }
                                        }
                                        
                                        HStack{
                                            Image("ic_money_send")
                                            TextView(text: "Start from $8k/month", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.neutral500.description)
                                        }.padding(.top, 16)
                                        
                                        HStack{
                                            Image("ic_clock")
                                            TextView(text: "Until 17 Dec, 2022", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.neutral500.description)
                                        }.padding(.top, 4)
                                        
                                    }.padding(16)
                                        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                        .cornerRadius(8)
                                        .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                                }
                                .padding(.horizontal, 24)
                                .padding(.vertical, 4)
                            }
                        }
                    }
                    
                    
                }
                
                Group {
                    
                    HStack{
                        TextView(text: "Open Jobs in Your Area", font: FontHelper.extraBold.description, size: 18, colorHex: ColorHelper.neutral500.description)
                        Spacer()
                        Button(action: {
                            
                        }, label: {
                            TextView(text: "See All", font: FontHelper.extraBold.description, size: 14, colorHex: ColorHelper.primary500.description)
                                
                        })
                    }.padding(.horizontal, 24)
                        .padding(.vertical, 12)
                    
                    HStack{
                        
                        VStack(alignment: .leading){
                            HStack{
                                Image("ic_figma")
                                VStack(alignment: .leading, spacing: 4){
                                    TextView(text: "UI Researcher", font: FontHelper.semibold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                                    TextView(text: "Figma", font: FontHelper.light.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                }
                                Spacer()
                                Image("ic_archive").padding(.bottom, 12)
                            }.padding(.bottom, 16)
                            
                            HStack(spacing: 4){
                                Button(action: {
                                    
                                }, label: {
                                    TextView(text: "Full Time", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                        .padding(.vertical, 4)
                                        .padding(.horizontal, 8)
                                        .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    TextView(text: "$12k/month", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                        .padding(.vertical, 4)
                                        .padding(.horizontal, 8)
                                        .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    TextView(text: "Remote", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                        .padding(.vertical, 4)
                                        .padding(.horizontal, 8)
                                        .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                                })
                            }
                            
                            HStack{
                                Image("ic_location")
                                TextView(text: "Erlangga 12 st.", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                Spacer()
                                TextView(text: "3 days left", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral500.description)
                            }.padding(.top, 16)
                            
                            
                        }
                        .padding(16)
                            .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                            .cornerRadius(8)
                            .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                    }
                    .padding(.horizontal, 24)
                    
                }
                
                
                
                
                Spacer()
            }
                
                
                
        }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

//
//  FilterJobView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 30/08/23.
//

import SwiftUI

struct FilterJobView: View {
    @State private var selected = 1
    @Environment(\.colorScheme) var colorScheme
    
    @State private var isOn = false
    @State private var isOn2 = false
    @State private var isOn3 = false
    @State private var isOn4 = false
    @State private var isOn5 = false
    @State private var isOn6 = false
    @State private var isOn7 = false
    @State private var isOn8 = false
    @State private var isOn9 = false
    @State private var isOn10 = false
    
    var body: some View {
        ZStack {
            VStack(alignment: .leading) {
                
                Group {
                    
                    VStack(alignment: .leading, spacing: 14) {
                        TextView(text: "Sort By", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                        RadioButtonSortby { selected in
                            print("Selected Gender is: \(selected)")
                        }
                    }.padding(.bottom, 16)
                    
                    VStack(alignment: .leading, spacing: 14) {
                        TextView(text: "Date Posted", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                        RadioButtonDatePosted { selected in
                            print("Selected Gender is: \(selected)")
                        }
                    }.padding(.bottom, 16)
                    
                    VStack(alignment: .leading, spacing: 14) {
                        TextView(text: "Experience Level", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                        HStack{
                            Toggle(isOn: $isOn) {
                                Text("Internship").font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                            .padding(.trailing, 72)
                            Toggle(isOn: $isOn2) {
                                Text("Entry Level")
                                    .font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn2 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                        }
                        HStack{
                            Toggle(isOn: $isOn3) {
                                Text("Associate").font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn3 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                            .padding(.trailing, 73)
                            Toggle(isOn: $isOn4) {
                                Text("Mid-Senior Level")
                                    .font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn4 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                        }
                        HStack{
                            Toggle(isOn: $isOn5) {
                                Text("Director").font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn5 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                            .padding(.trailing, 85)
                            Toggle(isOn: $isOn6) {
                                Text("Executive")
                                    .font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn6 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                        }
                    }.padding(.bottom, 16)
                }
                
                Group {
                    
                    VStack(alignment: .leading, spacing: 14) {
                        TextView(text: "Location", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                        HStack{
                            Toggle(isOn: $isOn7) {
                                Text("Jakarta").font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn7 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                            .padding(.trailing, 89)
                            Toggle(isOn: $isOn8) {
                                Text("Semarang")
                                    .font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn8 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                        }
                    }.padding(.bottom, 16)
                    
                    HStack{
                        TextView(text: "See More", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                        
                        Image("arrow_down")
                        
                    }.frame(maxWidth: .infinity)
                        .padding(.bottom, 12)
                    
                    Rectangle()
                        .foregroundColor(Color(hex: ColorHelper.neutral100.description))
                        .frame(maxWidth: .infinity)
                        .frame(height: 1)
                        .padding(.bottom, 16)
                    
                    VStack(alignment: .leading, spacing: 14) {
                        TextView(text: "Categories", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                        HStack{
                            Toggle(isOn: $isOn9) {
                                Text("Design").font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn9 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                            .padding(.trailing, 89)
                            Toggle(isOn: $isOn10) {
                                Text("Developer")
                                    .font(Font.custom(FontHelper.semibold.description, size: 14))
                                    .foregroundColor(isOn10 ? Color(hex: ColorHelper.neutral500.description) : Color(hex: ColorHelper.neutral300.description))
                            }
                            .toggleStyle(CheckBoxStyle())
                        }
                    }.padding(.bottom, 16)
                    
                    HStack{
                        TextView(text: "See More", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                        
                        Image("arrow_down")
                        
                    }.frame(maxWidth: .infinity)
                        .padding(.bottom, 12)
                    
                    Rectangle()
                        .foregroundColor(Color(hex: ColorHelper.neutral100.description))
                        .frame(maxWidth: .infinity)
                        .frame(height: 1)
                        .padding(.bottom, 16)
                
                }
                
                Spacer()
                
                Button(action: {
                    
                }, label: {
                    NavigationLink(destination: MainView(selection: 0)){
                        TextView(text: "Apply Filter", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.white.description)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                    }
                })
                
            }.padding(24)
        }
        .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    TextView(text: "Profile Setup", font: FontHelper.bold.description, size: 16, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                        .accessibilityAddTraits(.isHeader)
                }
            }
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
    }
}

struct FilterJobView_Previews: PreviewProvider {
    static var previews: some View {
        FilterJobView()
    }
}

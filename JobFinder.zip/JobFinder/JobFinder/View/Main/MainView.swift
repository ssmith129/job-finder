//
//  MainView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 11/07/23.
//

import SwiftUI


enum TabbedItems: Int, CaseIterable{
    case home = 0
    case favorite
    case chat
    case profile
    
    var imgInactive: String{
        switch self {
        case .home:
            return "home_inactive"
        case .favorite:
            return "discover_inactive"
        case .chat:
            return "message_inactive"
        case .profile:
            return "profile_inactive"
        }
    }
    
    var img: String{
        switch self {
        case .home:
            return "home"
        case .favorite:
            return "discover"
        case .chat:
            return "message"
        case .profile:
            return "profile"
        }
    }
}

struct MainView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @State var selection = 0
    @State private var oldSelectedItem = 1
    
    @State var selectedTab = 0
    
    var body: some View {
        
        ZStack(alignment: .bottom){
                    TabView(selection: $selectedTab) {
                        HomeView()
                            .tag(0)

                        DiscoverView()
                            .tag(1)

                        MessageView()
                            .tag(2)

                        ProfileView()
                            .tag(3)
                    }

                    ZStack{
                        HStack{
                            ForEach((TabbedItems.allCases), id: \.self){ item in
                                Button{
                                    selectedTab = item.rawValue
                                } label: {
                                    CustomTabItem(img: item.img, imgInactive: item.imgInactive, isActive: (selectedTab == item.rawValue))
                                }
                            }
                        }
                    }
                    .frame(height: 24)
        }.navigationBarBackButtonHidden(true)
        
        
        
//        ZStack{
//
//            TabView(selection: $selection) {
//
//                HomeView().tabItem {
//                    if selection == 0 {
//                        Image("home")
//                    } else {
//                        Image("home_inactive")
//                    }
//                }.tag(0)
//
//                DiscoverView().tabItem {
//                    if selection == 1 {
//                        Image("discover")
//                    } else {
//                        Image("discover_inactive")
//                    }
//                }.tag(1)
//
//                MessageView().tabItem {
//                    if selection == 2 {
//                        Image("message")
//                    } else {
//                        Image("message_inactive")
//                    }
//                }.tag(2)
//
//                ProfileView().tabItem {
//                    if selection == 3 {
//                        Image("profile")
//                    } else {
//                        Image("profile_inactive")
//                    }
//                }.tag(3)
//            }
//            .navigationBarBackButtonHidden(true)
//            .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
//        }
        
    }
}

extension MainView{
    
    
    func CustomTabItem(img: String, imgInactive: String, isActive: Bool) -> some View{
        HStack(spacing: 10){
            Spacer()
            Image(isActive ? img : imgInactive)
                .resizable()
                .frame(width: 24, height: 24)
            
            Spacer()
        }
        .frame(height: 56)
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}

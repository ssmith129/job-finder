//
//  MessageView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 19/08/23.
//

import SwiftUI

struct MessageView: View {
    
    var messages = [
        Messages(senderName: "Sarah Payton", message: "Let’s arrange a meeting tomorrow with the Manager", time: "2 min ago", countMessage: "3"),
        Messages(senderName: "Jack Ronerc", message: "I thought that your resume is nice!", time: "3:12 AM", countMessage: "1"),
        Messages(senderName: "John Jind", message: "Maybe not so much of that, we need more energy of your resume", time: "2 hr ago", countMessage: "0"),
        Messages(senderName: "Lei Riki", message: "You never gonna believe what i have to do", time: "Yesterday", countMessage: "0"),
        Messages(senderName: "Kamdo Tan", message: "Didn’t think that through, i think....", time: "2 days ago", countMessage: "0"),
        Messages(senderName: "Rias Gemr", message: "She really just said that i was the per...", time: "3 days ago", countMessage: "0"),
        Messages(senderName: "Rias Gemr", message: "She really just said that i was the per...", time: "3 days ago", countMessage: "0")
    ]
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack{
            VStack(alignment: .leading){
                
                ZStack{
                    
                    HStack{
                        TextView(text: "Message", font: FontHelper.extraBold.description, size: 24, colorHex: ColorHelper.white.description)
                        Spacer()
                        Button(action: {
                            
                        }, label: {
                            Image("btn_search_msg")
                        })
                    }
                }.padding(24)
                    .background(Color(hex: ColorHelper.neutral500.description))
                
                ForEach(messages) { message in
                    MessageRow(messages: message)
                }
                
                Spacer()
            }
            
            VStack{
                Spacer()
                Button(action: {
                    
                }, label: {
                    HStack{
                        Spacer()
                        Image("btn_menu_msg")
                    }
                })
            }
            
        }.background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
    }
}

struct MessageView_Previews: PreviewProvider {
    static var previews: some View {
        MessageView()
    }
}

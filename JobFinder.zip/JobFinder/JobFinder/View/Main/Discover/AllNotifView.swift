//
//  AllNotifView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 21/11/23.
//

import SwiftUI

struct AllNotifView: View {
    var body: some View {
        
        VStack{
            
            DividerView(label: "Today")
                .padding(.vertical, 24)
                .padding(.horizontal, 16)
            
            ZStack{
                HStack(alignment: .top){
                    Image("ic_dribbble")
                        .padding(.trailing, 4)
                    VStack(alignment: .leading, spacing: 6){
                        TextView(text: "Application Sent", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                        TextView(text: "Your application to Dribbble has been sent!\nCheck out other vacancy.", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral400.description)
                        HStack{
                            TextView(text: "2w ago", font: FontHelper.light.description, size: 14, colorHex: ColorHelper.neutral300.description)
                            Spacer()
                            Image("ic_more")
                        }
                    }
                }.padding(.horizontal, 16)
                    .padding(.vertical, 24)
                    .background(Color.white)
            }.padding(.bottom, 8)
            
            ZStack{
                HStack(alignment: .top){
                    Image("ic_shazam")
                        .padding(.trailing, 4)
                    VStack(alignment: .leading, spacing: 6){
                        TextView(text: "Your application is being reviewed!", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                        TextView(text: "Your application to Shazam is being\nreviewed! Stand by for more info!", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral400.description)
                        HStack{
                            TextView(text: "2w ago", font: FontHelper.light.description, size: 14, colorHex: ColorHelper.neutral300.description)
                            Spacer()
                            Image("ic_more")
                        }
                    }
                }.padding(.horizontal, 16)
                    .padding(.vertical, 24)
                    .background(Color.white)
            }.padding(.bottom, 8)
            
            ZStack{
                HStack(alignment: .top){
                    Image("ic_alfabank")
                        .padding(.trailing, 4)
                    VStack(alignment: .leading, spacing: 6){
                        TextView(text: "Your application turned down!", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                        TextView(text: "Your application to Alfabank co. is turned\ndown! Don’t worry, there is more\nvacancy coming!", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral400.description)
                        HStack{
                            TextView(text: "2w ago", font: FontHelper.light.description, size: 14, colorHex: ColorHelper.neutral300.description)
                            Spacer()
                            Image("ic_more")
                        }
                    }
                }.padding(.horizontal, 16)
                    .padding(.vertical, 24)
                    .background(Color.white)
            }.padding(.bottom, 16)
            
            
            DividerView(label: "2 days ago")
                .padding(.bottom, 16)
                .padding(.horizontal, 16)
            
            ZStack{
                HStack(alignment: .top){
                    Image("ic_ae")
                        .padding(.trailing, 4)
                    VStack(alignment: .leading, spacing: 6){
                        TextView(text: "Your application turned down!", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                        TextView(text: "Your application to Ae Corporation is turned\ndown! Don’t worry, there is more\nvacancy coming!", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral400.description)
                        HStack{
                            TextView(text: "2w ago", font: FontHelper.light.description, size: 14, colorHex: ColorHelper.neutral300.description)
                            Spacer()
                            Image("ic_more")
                        }
                    }
                }.padding(.horizontal, 16)
                    .padding(.vertical, 24)
                    .background(Color.white)
            }.padding(.bottom, 16)
            
            Spacer()
        }
            .background(Color(hex: ColorHelper.bgBorder.description))
        
    }
}

#Preview {
    AllNotifView()
}

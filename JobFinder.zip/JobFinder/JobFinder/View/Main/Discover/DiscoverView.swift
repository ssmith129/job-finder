//
//  DiscoverView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 19/08/23.
//

import SwiftUI

struct DiscoverView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack{
            VStack{
                
                Group {
                    VStack(spacing: 0){
                        
                        ZStack{
                            
                            VStack {
                                
                                HStack{
                                    
                                    TextView(text: "Explore the best job", font: FontHelper.extraBold.description, size: 24, colorHex: ColorHelper.white.description)
                                    Spacer()
                                    Image("btn_notif_explore")
                                }.padding(.bottom, 20)
                                
                                HStack{
                                    
                                    Button(action: {
                                        
                                    }) {
                                        HStack {
                                            NavigationLink(destination: JobListSearchView()){
                                                Text("Search Jobs...")
                                                    .font(.custom(FontHelper.medium.description,size: 14))
                                                    .foregroundColor(Color(hex: ColorHelper.neutral300.description))
                                                    .frame(maxWidth: .infinity, alignment: .leading)
                                                    .padding(EdgeInsets(top: 12, leading: 56, bottom: 12, trailing: 24))
                                            }
                                        }.overlay(alignment: .leading){
                                            Image("ic_search")
                                                .padding(.leading, 20)
                                        }
                                    }
                                    .frame(height: 48)
                                    .shadow(color: Color.black.opacity(0.08), radius: 60, x: 0.0, y: 16)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color(hex: ColorHelper.neutral400.description), lineWidth: 1.5)
                                    )
                                    .background(
                                        RoundedRectangle(cornerRadius: 8).fill(Color(hex: ColorHelper.neutral500.description))
                                    )
                                    Spacer()
                                    Spacer()
                                    Button(action: {
                                        
                                    }, label: {
                                        NavigationLink(destination: FilterJobView()){
                                            Image("btn_filter")
                                        }
                                    })
                                }
                                
                            }
                            
                        }.padding(24)
                            .background(Color(hex: ColorHelper.neutral500.description))
                        
                    }
                }
                
                ScrollView(showsIndicators: false) {
                    
                    Group {
                        VStack(alignment: .leading){
                            TextView(text: "Sponsored vacancy", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                                .padding(.bottom, 12)
                            
                            VStack(spacing: 0){
                                
                                Image("img_explore1")
                                
                                VStack(alignment: .leading){
                                    
                                    HStack{
                                        Image("ic_dribbble")
                                        VStack(alignment: .leading, spacing: 4){
                                            TextView(text: "UI Researcher", font: FontHelper.semibold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                                            TextView(text: "Dribbble", font: FontHelper.light.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                        }
                                        Spacer()
                                        Image("ic_archive").padding(.bottom, 12)
                                    }.padding(.bottom, 16)
                                    
                                    HStack(spacing: 4){
                                        Button(action: {
                                            
                                        }, label: {
                                            TextView(text: "Full Time", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                                .padding(.vertical, 4)
                                                .padding(.horizontal, 8)
                                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                                        })
                                        
                                        Button(action: {
                                            
                                        }, label: {
                                            TextView(text: "$12k/month", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                                .padding(.vertical, 4)
                                                .padding(.horizontal, 8)
                                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                                        })
                                        
                                        Button(action: {
                                            
                                        }, label: {
                                            TextView(text: "Remote", font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral300.description)
                                                .padding(.vertical, 4)
                                                .padding(.horizontal, 8)
                                                .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                                        })
                                    }
                                }
                                .padding(16)
                                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                                .cornerRadius(8)
                                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
                                
                            }
                            
                            
                            
                        }.padding(24)
                        
                        HStack {
                            
                            TextView(text: "Browse by category", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                            Spacer()
                            TextView(text: "See all", font: FontHelper.medium.description, size: 12, colorHex: ColorHelper.primary500.description)
                            
                        }.padding(.horizontal, 24)
                            .padding(.bottom, 12)
                    }
                    
                    Group {
                        HStack(spacing: 16) {
                            
                            CategoryExploreView(imgLight: "chart_active", imgDark: "chart_inactive", text: "Big Data")
                            CategoryExploreView(imgLight: "design_light", imgDark: "design", text: "Design")
                            CategoryExploreView(imgLight: "finance_light", imgDark: "finance", text: "Finance")
                            
                        }.padding(.horizontal, 24)
                            .padding(.bottom, 12)
                        
                        HStack(spacing: 16) {
                            
                            CategoryExploreView(imgLight: "code_light", imgDark: "code", text: "Programmer")
                            CategoryExploreView(imgLight: "composer_light", imgDark: "composer", text: "Composer")
                            CategoryExploreView(imgLight: "writer_light", imgDark: "writer", text: "Writer")
                            
                        }.padding(.horizontal, 24)
                            .padding(.bottom, 12)
                        
                        HStack(spacing: 16) {
                            
                            CategoryExploreView(imgLight: "hrd_light", imgDark: "hrd", text: "HRD")
                            CategoryExploreView(imgLight: "photographer_light", imgDark: "photographer", text: "Editor")
                            CategoryExploreView(imgLight: "game_light", imgDark: "game", text: "Gamer")
                            
                        }.padding(.horizontal, 24)
                            .padding(.bottom, 12)
                    }
                    
                    Group {
                        
                        HStack{
                            TextView(text: "Most viewed company", font: FontHelper.bold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                            Spacer()
                        }.padding(.horizontal, 24)
                        
                        HStack{
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 12){
                                    VStack{
                                        ZStack{
                                            
                                            Image("img_most_viewed_1")
                                            
                                            Rectangle()
                                                .foregroundColor(.clear)
                                                .background(
                                                    LinearGradient(
                                                        stops: [
                                                            Gradient.Stop(color: .black.opacity(0), location: 0.00),
                                                            Gradient.Stop(color: .black, location: 1.00),
                                                        ],
                                                        startPoint: UnitPoint(x: 0.5, y: 0),
                                                        endPoint: UnitPoint(x: 0.5, y: 1.14)
                                                    )
                                                )
                                                .cornerRadius(8)
                                            
                                            VStack(alignment: .leading) {
                                                HStack{
                                                    Image("ic_qiwi")
                                                    Spacer()
                                                    
                                                }
                                                
                                                TextView(text: "Qiwi", font: FontHelper.extraBold.description, size: 16, colorHex: ColorHelper.white.description)
                                                    .padding(.bottom, 0.5)
                                                
                                                TextView(text: "Jakarta, Indonesia", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.white.description)
                                                    .padding(.bottom, 6)
                                                
                                                HStack{
                                                    Image("img_group_person")
                                                    
                                                    Spacer()
                                                    Image("ic_star")
                                                    TextView(text: "4.5 Ratings", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.white.description)
                                                    
                                                    Spacer()
                                                    Image("ic_eye")
                                                    TextView(text: "12k Views", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.white.description)
                                                }
                                                
                                            }.padding(.horizontal, 16)
                                            
                                        }
                                    }
                                    .frame(width: 300, height: 152)
                                    
                                    VStack{
                                        ZStack{
                                            
                                            Image("img_most_viewed_1")
                                            
                                            Rectangle()
                                                .foregroundColor(.clear)
                                                .background(
                                                    LinearGradient(
                                                        stops: [
                                                            Gradient.Stop(color: .black.opacity(0), location: 0.00),
                                                            Gradient.Stop(color: .black, location: 1.00),
                                                        ],
                                                        startPoint: UnitPoint(x: 0.5, y: 0),
                                                        endPoint: UnitPoint(x: 0.5, y: 1.14)
                                                    )
                                                )
                                                .cornerRadius(8)
                                            
                                            VStack(alignment: .leading) {
                                                HStack{
                                                    Image("ic_qiwi")
                                                    Spacer()
                                                    
                                                }
                                                
                                                TextView(text: "Qiwi", font: FontHelper.extraBold.description, size: 16, colorHex: ColorHelper.white.description)
                                                    .padding(.bottom, 0.5)
                                                
                                                TextView(text: "Jakarta, Indonesia", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.white.description)
                                                    .padding(.bottom, 6)
                                                
                                                HStack{
                                                    Image("img_group_person")
                                                    
                                                    Spacer()
                                                    Image("ic_star")
                                                    TextView(text: "4.5 Ratings", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.white.description)
                                                    
                                                    Spacer()
                                                    Image("ic_eye")
                                                    TextView(text: "12k Views", font: FontHelper.light.description, size: 12, colorHex: ColorHelper.white.description)
                                                }
                                                
                                            }.padding(.horizontal, 16)
                                            
                                        }
                                    }
                                    .frame(width: 300, height: 152)
                                    
                                }
                                .padding(.horizontal, 24)
                                .padding(.vertical, 16)
                            }
                        }
                        
                        
                    }
                    
                    
                }
                
                Spacer()
                
            }
        }
        .frame(maxWidth: .infinity)
        .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.bgBorder.description))
    }
}

struct DiscoverView_Previews: PreviewProvider {
    static var previews: some View {
        DiscoverView()
    }
}

struct CategoryExploreView: View {
    
    @Environment(\.colorScheme) var colorScheme
    var imgLight: String
    var imgDark: String
    var text: String
    
    var body: some View {
        
        Button(action: {
            
        }) {
            VStack(spacing: 12){
                Image(colorScheme == .dark ? imgDark : imgLight)
                VStack(alignment: .leading){
                    TextView(text: text, font: FontHelper.semibold.description, size: 14, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral300.description)
                }
            }
            .frame(width: 100, height: 100)
            .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
            .cornerRadius(8)
            .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
        }
        
    }
}

//
//  MessageRow.swift
//  JobFinder
//
//  Created by Farhan Mazario on 27/09/23.
//

import SwiftUI

struct MessageRow: View {
    
    @Environment(\.colorScheme) var colorScheme
    var messages: Messages
    
    var body: some View {
        
        HStack{
            
            VStack(alignment: .leading){
                HStack{
                    Image("img_avatar")
                    VStack(spacing: 8){
                        HStack{
                            TextView(text: messages.senderName, font: FontHelper.semibold.description, size: 14, colorHex: ColorHelper.neutral500.description)
                            Spacer()
                            TextView(text: messages.time, font: FontHelper.semibold.description, size: 12, colorHex: ColorHelper.neutral300.description)
                        }
                        HStack{
                            TextView(text: messages.message, font: FontHelper.semibold.description, size: 12, colorHex: ColorHelper.neutral300.description)
                                .truncationMode(.tail)
                                .lineLimit(1)
                                .padding(.trailing, 32)
                            Spacer()
                            Text(messages.countMessage)
                                .font(.custom(FontHelper.bold.description, size: 12))
                                .padding(5)
                                .background(
                                    Circle()
                                        .fill(Color(hex: messages.countMessage == "0" ? ColorHelper.white.description : ColorHelper.primary500.description))
                                )
                                .foregroundColor(.white)
                        }
                    }
                }
            }
            .padding(24)
                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
        }
        
    }
}

struct MessageRow_Previews: PreviewProvider {
    static var previews: some View {
        MessageRow(messages: Messages(senderName: "John Doe", message: "Let’s arrange a meeting tomorrow will have the bos and manager", time: "2 min ago", countMessage: "2"))
    }
}

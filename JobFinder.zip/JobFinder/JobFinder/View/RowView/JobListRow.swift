//
//  JobListRow.swift
//  JobFinder
//
//  Created by Farhan Mazario on 28/08/23.
//

import SwiftUI

struct JobListRow: View {
    
    @Environment(\.colorScheme) var colorScheme
    var jobList: JobList
    
    var body: some View {
        HStack{
            
            VStack(alignment: .leading){
                HStack{
                    Image(jobList.image)
                    VStack(alignment: .leading, spacing: 4){
                        TextView(text: jobList.jobName, font: FontHelper.semibold.description, size: 16, colorHex: ColorHelper.neutral500.description)
                        TextView(text: jobList.company, font: FontHelper.light.description, size: 14, colorHex: ColorHelper.neutral300.description)
                    }
                    Spacer()
                    Image("ic_archive").padding(.bottom, 12)
                }.padding(.bottom, 16)
                
                HStack(spacing: 4){
                    Button(action: {
                        
                    }, label: {
                        TextView(text: "Full Time", font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                            .padding(.vertical, 4)
                            .padding(.horizontal, 8)
                            .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                    })
                    
                    Button(action: {
                        
                    }, label: {
                        TextView(text: jobList.salary, font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                            .padding(.vertical, 4)
                            .padding(.horizontal, 8)
                            .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                    })
                    
                    Button(action: {
                        
                    }, label: {
                        TextView(text: jobList.jobType, font: FontHelper.bold.description, size: 14, colorHex: ColorHelper.neutral300.description)
                            .padding(.vertical, 4)
                            .padding(.horizontal, 8)
                            .background(Color(hex: ColorHelper.neutral300.description, opacity: 0.2), in:RoundedRectangle(cornerRadius: 8))
                    })
                }
                
                HStack{
                    Image("ic_location")
                    TextView(text: jobList.location, font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral300.description)
                    Spacer()
                    TextView(text: jobList.date, font: FontHelper.medium.description, size: 14, colorHex: ColorHelper.neutral500.description)
                }.padding(.top, 16)
                
                
            }
            .padding(16)
                .background(Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.white.description))
                .cornerRadius(8)
                .shadow(color: .black.opacity(0.05), radius: 15, x: 0, y: 12)
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 24)
    }
}

struct JobListRow_Previews: PreviewProvider {
    static var previews: some View {
        JobListRow(jobList: JobList(jobName: "Designer", image: "ic_figma", company: "Figma", location: "Semarang, Indonesia", salary: "$12k per month", jobType: "Remote", date: "3 days left"))
    }
}

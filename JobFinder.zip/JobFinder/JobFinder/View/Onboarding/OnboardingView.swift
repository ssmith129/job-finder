//
//  OnboardingView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 15/06/23.
//

import SwiftUI

private let onboardings = [
    Onboarding(image: "onboarding1", title: "What you seek is\nalways there.", desc: "The thing you do, there is always people that\nlook for it, you just have to search for it."),
    Onboarding(image: "onboarding2", title: "Opportunity can be what you want", desc: "Experience the good seeking job that will help you guide and make sure you got your job."),
    Onboarding(image: "onboarding3", title: "Be organized like never before!", desc: "Multitasking, organizing, leading and many more that will upgrade you to the fullest.")
]

struct OnboardingView: View {
    
    @Environment(\.colorScheme) var colorScheme
    var screenSize: CGSize
    @State var offset: CGFloat = 0
    @State private var currentOnboarding = 0
    
    var body: some View {
        
        ZStack{
            NavigationView {
                
                VStack{
                    ///
                    TabView(selection: $currentOnboarding) {
                        ForEach(0..<onboardings.count, id: \.self){ it in
                            VStack{
                                ZStack{
                                    Image(onboardings[it].image)
                                        .resizable()
                                        .frame(height: 472)
                                        .aspectRatio(contentMode: .fit)
                                        .padding(.top, 24)
                                }
                                .frame(width: screenSize.width)
                                .background(Color(hex: ColorHelper.neutral500.description))
                                
                                        
                                VStack(alignment: .center) {
                                    
                                    //Animated Indicator
                                    HStack(alignment: .center, spacing: 10){
                                        
                                        ForEach(0..<onboardings.count, id: \.self){ index in
                                            if index == currentOnboarding {
                                                Rectangle()
                                                    .frame(width: 32, height: 8)
                                                    .cornerRadius(8)
                                                    .foregroundColor(Color(hex: ColorHelper.primary500.description))
                                            } else {
                                                Circle()
                                                    .frame(width: 8, height: 8)
                                                    .foregroundColor(Color(hex: colorScheme == .dark ? ColorHelper.neutral400.description : ColorHelper.primary100.description))
                                            }
                                        }
                                    }
                                    .padding(.top, 24)
                                    
                                    TextView(text: onboardings[it].title, font: FontHelper.extraBold.description, size: 36, colorHex: colorScheme == .dark ? ColorHelper.white.description : ColorHelper.neutral500.description)
                                        .multilineTextAlignment(.center)
                                        .padding(.top, 40)
                                        .padding(.horizontal, 20)
                                    TextView(text: onboardings[it].desc, font: FontHelper.medium.description, size: 16, colorHex: ColorHelper.neutral300.description)
                                        .multilineTextAlignment(.center)
                                        .padding(.top, 16)
                                        .padding(.horizontal, 24)
                                    Spacer()
                                    
                                }
                                .tag(it)
                                .frame(width: screenSize.width)
                                .background(Color.white)
                                .cornerRadius(40.0, corners: [.topLeft, .topRight])
                                .offset(y: -128)
                            }
                            .frame(width: screenSize.width)
                        }
                    }.tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    
                    ///
                    Spacer()
                    HStack{
                        if self.currentOnboarding < onboardings.count - 1 {
                            Button(action: {
                                if self.currentOnboarding == onboardings.count - 2 {
                                    self.currentOnboarding += 1
                                } else if self.currentOnboarding < onboardings.count - 1 {
                                    self.currentOnboarding += 2
                                }
                            }) {
                                Text("Skip")
                                    .font(.custom(FontHelper.extraBold.description, size: 16))
                                    .foregroundColor(Color(hex: ColorHelper.neutral200.description))
                            }
                            Spacer()
                            Button(action: {
                                if self.currentOnboarding < onboardings.count - 1 {
                                    self.currentOnboarding += 1
                                }
                            }) {
                                TextView(text: "Next", font: FontHelper.extraBold.description, size: 16, colorHex: ColorHelper.white.description)
                                    .padding(.vertical, 16)
                                    .padding(.horizontal, 48)
                                    .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                            }
                        } else {
                            Button(action: {
                                    
                            }, label: {
                                NavigationLink(destination: LoginView()){
                                    TextView(text: "Get Started", font: FontHelper.extraBold.description, size: 16, colorHex: ColorHelper.white.description)
                                        .padding(.vertical, 20)
                                        .frame(maxWidth: .infinity)
                                        .background(Color(hex: ColorHelper.primary500.description), in:RoundedRectangle(cornerRadius: 8))
                                }
                            })
                        }
                        
                        
                    }.padding(.bottom, 24)
                        .padding(.horizontal, 32)
                }
                
            }.navigationViewStyle(StackNavigationViewStyle())
        }.edgesIgnoringSafeArea(.top)
        
        
    }
    
    // Offset for indicator..
    func getIndicatorOffset()->CGFloat{
        
        let progress = offset / screenSize.width
        
        //10 : spacing
        //8 : Circle size
        let maxWidth: CGFloat = 10 + 8
        
        return progress * maxWidth
        
    }
    
    
    // Expanding index based on offset..
    func getIndex()->Int{
        let progress = round(offset / screenSize.width)
        
        //For saftey..
        let index = min(Int(progress), onboardings.count - 1)
        return index
    }
}

struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape( RoundedCorner(radius: radius, corners: corners) )
    }
}

struct RoundedCorner: Shape {
    
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}


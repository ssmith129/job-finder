//
//  SplashScreenView.swift
//  JobFinder
//
//  Created by Farhan Mazario on 15/06/23.
//

import SwiftUI

struct SplashScreenView: View {
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("isDarkMode") private var isDarkMode = false
    @State var isActive: Bool = false
    
    var body: some View {
        
        ZStack {
            if self.isActive {
                GeometryReader{proxy in
                    let size = proxy.size
                    OnboardingView(screenSize: size)
                }
                
            } else {
                ZStack{
                    Color(hex: colorScheme == .dark ? ColorHelper.neutral500.description : ColorHelper.primary500.description)
                        .edgesIgnoringSafeArea(.all)
                    VStack{
                        Image(colorScheme == .dark ? "logo_dark" :"logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 64, height: 64)
                        TextView(text: "JobFinder", font: FontHelper.extraBold.description, size: 48, colorHex: ColorHelper.white.description)
                    }
                    VStack{
                        Spacer()
                        Image(colorScheme == .dark ? "splash_bottom_dark" : "splash_bottom")
                    }.edgesIgnoringSafeArea(.all)
                }
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                withAnimation {
                    self.isActive = true
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        
        
    }
}

struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView()
    }
}

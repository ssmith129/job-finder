//
//  JobFinderApp.swift
//  JobFinder
//
//  Created by Farhan Mazario on 15/06/23.
//

import SwiftUI

@main
struct JobFinderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

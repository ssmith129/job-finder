//
//  Messages.swift
//  JobFinder
//
//  Created by Farhan Mazario on 27/09/23.
//

import Foundation

struct Messages: Identifiable {
    let id = UUID()
    let senderName: String
    let message: String
    let time: String
    var countMessage: String
}

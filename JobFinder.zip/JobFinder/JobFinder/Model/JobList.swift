//
//  JobList.swift
//  JobFinder
//
//  Created by Farhan Mazario on 28/08/23.
//

import Foundation

struct JobList: Identifiable {
    let id = UUID()
    let jobName: String
    let image: String
    let company: String
    let location: String
    let salary: String
    let jobType: String
    let date: String
}

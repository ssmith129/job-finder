//
//  Onboarding.swift
//  JobFinder
//
//  Created by Farhan Mazario on 07/07/23.
//

import Foundation

struct Onboarding: Identifiable {
    var id = UUID().uuidString
    let image: String
    let title: String
    let desc: String
}


